import React from "react";


function Note(){
  return (
    <div className="Note">
    <h1> javascript and react.js </h1>
    <p> AMAZING BOOTCAMP </p>
    </div>

  );
}
export default Header;