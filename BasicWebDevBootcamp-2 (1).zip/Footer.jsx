import React from "react";

function Footer(){
  var currYear=new Date().getFullYear();
  return (
    <Footer>
    <h1>Copyright @ {currYear}</h1>

    </Footer>

  );
}
export default Footer;